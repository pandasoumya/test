

--Challenge: Duplicate Email Addresses
select email from Employee 
group by email
having COUNT(email) > 1

--Challenge: Department Highest Salaries

select Department,Employee, Salary from (select d.name as Department, e.name as Employee, e.salary as Salary, 
rank() over(partition by d.departmentId order by e.salary desc) sal_rank
from Employee e
inner join Department d
on e.departmentId = d.departmentId
) x
where sal_rank = 1