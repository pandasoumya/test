USE [wtw]
GO
/****** Object:  Table [dbo].[camp_reservation]    Script Date: 2023-02-12 5:38:00 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[camp_reservation](
	[reservation_id] [int] IDENTITY(1,1) NOT NULL,
	[reservation_start_date] [date] NOT NULL,
	[reservation_end_date] [date] NOT NULL,
	[camp_site_id] [int] NOT NULL,
	[visitors_no] [int] NOT NULL,
 CONSTRAINT [PK_camp_reservation] PRIMARY KEY CLUSTERED 
(
	[reservation_id] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, OPTIMIZE_FOR_SEQUENTIAL_KEY = OFF) ON [PRIMARY]
) ON [PRIMARY]
GO
/****** Object:  Table [dbo].[camp_site]    Script Date: 2023-02-12 5:38:01 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[camp_site](
	[camp_site_id] [int] IDENTITY(1,1) NOT NULL,
	[camp_site_name] [varchar](50) NULL,
 CONSTRAINT [PK_cam_site] PRIMARY KEY CLUSTERED 
(
	[camp_site_id] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, OPTIMIZE_FOR_SEQUENTIAL_KEY = OFF) ON [PRIMARY]
) ON [PRIMARY]
GO
SET IDENTITY_INSERT [dbo].[camp_reservation] ON 
GO
INSERT [dbo].[camp_reservation] ([reservation_id], [reservation_start_date], [reservation_end_date], [camp_site_id], [visitors_no]) VALUES (1, CAST(N'2023-02-12' AS Date), CAST(N'2023-02-15' AS Date), 1, 5)
GO
INSERT [dbo].[camp_reservation] ([reservation_id], [reservation_start_date], [reservation_end_date], [camp_site_id], [visitors_no]) VALUES (2, CAST(N'2023-02-20' AS Date), CAST(N'2023-02-25' AS Date), 2, 10)
GO
INSERT [dbo].[camp_reservation] ([reservation_id], [reservation_start_date], [reservation_end_date], [camp_site_id], [visitors_no]) VALUES (3, CAST(N'2023-02-12' AS Date), CAST(N'2023-02-13' AS Date), 3, 3)
GO
INSERT [dbo].[camp_reservation] ([reservation_id], [reservation_start_date], [reservation_end_date], [camp_site_id], [visitors_no]) VALUES (4, CAST(N'2023-02-05' AS Date), CAST(N'2023-02-09' AS Date), 1, 7)
GO
SET IDENTITY_INSERT [dbo].[camp_reservation] OFF
GO
SET IDENTITY_INSERT [dbo].[camp_site] ON 
GO
INSERT [dbo].[camp_site] ([camp_site_id], [camp_site_name]) VALUES (1, N'CS1')
GO
INSERT [dbo].[camp_site] ([camp_site_id], [camp_site_name]) VALUES (2, N'CS2')
GO
INSERT [dbo].[camp_site] ([camp_site_id], [camp_site_name]) VALUES (3, N'CS3')
GO
SET IDENTITY_INSERT [dbo].[camp_site] OFF
GO
