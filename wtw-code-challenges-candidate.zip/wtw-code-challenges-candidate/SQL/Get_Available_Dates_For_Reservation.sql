

CREATE PROCEDURE Get_AvailableDates_For_Reservation  
	@start_date date, 
    @end_date date,
	@camp_site_id int
as 

CREATE TABLE #booked_dates (
    booked_dates date,
);

CREATE TABLE #available_dates (
    available_dates date,
);

WITH DatesList(Dates) AS
(    
    SELECT @start_date AS DATE
    UNION ALL
    SELECT DATEADD(DAY,1,Dates)
    FROM DatesList 
    WHERE Dates < @end_date
)
insert into #available_dates
SELECT Dates
FROM DatesList

DECLARE cursor_reservation CURSOR
FOR select reservation_start_date, reservation_end_date 
from [dbo].[camp_reservation] where camp_site_id = @camp_site_id
order by reservation_start_date;
OPEN cursor_reservation;
FETCH NEXT FROM cursor_reservation INTO @start_date, @end_date;
WHILE @@FETCH_STATUS = 0  
    BEGIN
		--PRINT CAST(@start_date AS varchar) + ' - ' + CAST(@end_date AS varchar);
		DECLARE @StartDate DATE, @EndDate DATE
		SELECT @StartDate = @start_date, @EndDate = @end_date; 
		WITH ListDates(AllDates) AS
		(    SELECT @StartDate AS DATE
			UNION ALL
			SELECT DATEADD(DAY,1,AllDates)
			FROM ListDates 
			WHERE AllDates < @EndDate
		)
		insert into #booked_dates
		SELECT AllDates from ListDates
        FETCH NEXT FROM cursor_reservation INTO @start_date, @end_date;  
    END;

--select booked_dates from #booked_dates 
select available_dates from #available_dates 
where available_dates not in (		
		select booked_dates from #booked_dates 
)
order by available_dates;

drop table #booked_dates;
drop table #available_dates;
CLOSE cursor_reservation;
DEALLOCATE cursor_reservation;
