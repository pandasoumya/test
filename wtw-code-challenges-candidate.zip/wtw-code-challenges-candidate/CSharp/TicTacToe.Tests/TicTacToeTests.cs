using System;
using Xunit;

namespace TicTacToe.Tests
{
    public class TicTacToeTests
    {
        [Fact]
        public void Test_FindWinner()
        {
            // Arrange  
            int[,] boardArray = { { 2, 2, 1 }, 
                                  { 2, 1, 2 },
                                  { 2, 1, 2 } };
            int[] result = To1DArray(boardArray);
            var expected = 2;
            //Act
            ITicTacToe ttt = new TicTacToe();
            ttt.Size = 3;
            var actual = ttt.FindWinner(result);
            //Assert
            Assert.Equal(expected, actual);
        }

        private int[] To1DArray(int[,] input)
        {
            int size = input.Length;
            int[] result = new int[size];

            int write = 0;
            for (int i = 0; i <= input.GetUpperBound(0); i++)
            {
                for (int z = 0; z <= input.GetUpperBound(1); z++)
                {
                    result[write++] = input[i, z];
                }
            }
            return result;
        }
    }
}