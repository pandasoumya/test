﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace TicTacToe
{
    public class TicTacToe : ITicTacToe
    {
        private static int _size { get; set; }
        public int Size
        {
            get { return _size; }
            set { _size = value; }
        }
        public int[,] Matrix
        {
            get { return new int[Size, Size]; }
        }
        //public int PlacePiece(int row, int col, int player)
        //{
        //    Matrix[row, col] = player;
        //    bool validMatrix = false;
        //    foreach (int i in Matrix)
        //    {
        //        if (i == 0)
        //        {
        //            validMatrix = false;
        //        }
        //        else
        //        {
        //            validMatrix = true;
        //        }
        //    }
        //    if (Size >= 3 && validMatrix)
        //    {
        //        return FindWinner(Matrix.Cast<int>().ToArray(), player);
        //    }
        //    else
        //    {
        //        return 0;
        //    }
        //}
        public int FindWinner(int[] boardArray)
        {
            //int[] positionArray = Enumerable.Range(1, Size * Size).ToArray();
            //int playerTurn = 0;
            //WinningCriteria critera = WinningCriteria.Loss;
            //int player;
            //while (critera != WinningCriteria.Win && critera != WinningCriteria.Draw)
            //{
            //    int position = boardArray[playerTurn];
            //    int positionIndex = position - 1;
            //    if (boardArray[positionIndex] != -1 && boardArray[positionIndex] != -2)
            //    {
            //        if (playerTurn % 2 == 1)
            //        {
            //            boardArray[positionIndex] = -1;
            //            playerTurn++;
            //            player = 1;
            //        }
            //        else
            //        {
            //            boardArray[positionIndex] = -2;
            //            playerTurn++;
            //            player = 2;
            //        }
            //    }
                //int player = VerifyWinningCriteria(boardArray, Size);
            //}

            return VerifyWhoWon(boardArray, Size);
        }
        private int VerifyWhoWon(int[] boardArray, int size)
        {
            int player = 0;
            if (CheckHorizontal(boardArray, size, ref player))
                return player;

            if (CheckVertical(boardArray, size, ref player))
                return player;

            if (CheckDiagonal(boardArray, size, ref player))
                return player;

            if (CheckDraw(boardArray, size))
                return 0;
            else
            {
                return player;
            }
        }
        private bool CheckHorizontal(int[] boardArray, int size, ref int player)
        {
            int row = size;
            bool breakWinHorizontal = true;
            int playerVal = 0;
            while (row != 0)
            {
                int startIndex = size * (row - 1);
                int endIndex = (size * row) - 1;
                breakWinHorizontal = true;
                for (int i = startIndex; i < endIndex; i++)
                {
                    if (boardArray[i] != boardArray[i + 1])
                    {
                        breakWinHorizontal = !breakWinHorizontal;
                        playerVal = boardArray[i];
                        break;
                    }
                    else
                    {
                        playerVal = boardArray[i + 1];
                    }
                }
                if (breakWinHorizontal)
                {
                    player = playerVal;
                    return breakWinHorizontal;
                }
                row--;
            }
            player = playerVal;
            return breakWinHorizontal;
        }
        private bool CheckVertical(int[] boardArray, int size, ref int player)
        {
            int col = size;
            bool breakWinVertical = true;
            int playerVal = 0;
            while (col != 0)
            {
                int[] colIndices = new int[size];
                for (int ind = size - 1; ind >= 0; ind--)
                {
                    colIndices[ind] = size * ind + (col - 1);
                }
                breakWinVertical = true;
                for (int i = 0; i < colIndices.Length - 1; i++)
                {
                    if (boardArray[colIndices[i]] != boardArray[colIndices[i + 1]])
                    {
                        breakWinVertical = !breakWinVertical;
                        playerVal = boardArray[colIndices[i]];
                        break;
                    }
                    else
                    {
                        playerVal = boardArray[colIndices[i + 1]];
                    }
                }
                if (breakWinVertical)
                {
                    player = playerVal;
                    return breakWinVertical;
                }
                col--;
            }
            player = playerVal;
            return breakWinVertical;
        }
        private bool CheckDiagonal(int[] boardArray, int size, ref int player)
        {
            int col = size;
            int[] top2bottomIndices = new int[size];
            int[] bottom2topIndices = new int[size];
            while (col != 0)
            {
                int colIdx = col - 1;
                top2bottomIndices[colIdx] = (size + 1) * colIdx;
                bottom2topIndices[colIdx] = (size - 1) * (colIdx + 1);
                col--;
            }
            player = 0;
            return (CheckDiagonallyCrosswards(boardArray, top2bottomIndices, size, ref player) || CheckDiagonallyCrosswards(boardArray, bottom2topIndices, size, ref player));
        }
        private bool CheckDiagonallyCrosswards(int[] boardArray, int[] crossIndices, int size, ref int player)
        {
            bool breakWinDiagonal = true;
            int playerVal = 0;
            for (int i = 0; i < crossIndices.Length - 1; i++)
            {
                if (boardArray[crossIndices[i]] != boardArray[crossIndices[i + 1]])
                {
                    breakWinDiagonal = !breakWinDiagonal;
                    playerVal = boardArray[crossIndices[i]];
                    break;
                }
                else
                {
                    playerVal = boardArray[crossIndices[i + 1]];
                }
            }
            player = playerVal;
            return breakWinDiagonal;
        }
        private bool CheckDraw(int[] boardArray, int size)
        {
            bool isDraw = false;
            int[] fieldSector = Enumerable.Range(1, size * size).ToArray();
            for (int i = 0; i < Math.Pow(size, 2); i++)
            {
                if (boardArray[i] == fieldSector[i])
                {
                    isDraw = !isDraw;
                    break;
                }
            }
            return isDraw;
        }       
    }
}
