﻿using System;
using System.Collections.Generic;

namespace UniqueEmailAddresses
{
    public static class UniqueEmailAddresses
    {      
        public static int NumberOfUniqueEmailAddresses(string[] emails)
        {
            List<string> uniqueEmailList = new List<string>();
            foreach (string email in emails)
            {
                string[] emailPartArray = email.Split('@');
                string localPart = emailPartArray[0].Replace(".", "");
                string domainPart = emailPartArray[1];
                if (localPart.Contains('+'))
                {
                    localPart = localPart.Substring(0, localPart.IndexOf("+"));
                }
                string validEmail = string.Join("@", localPart, domainPart);
                if (!uniqueEmailList.Contains(validEmail))
                {
                    uniqueEmailList.Add(validEmail);
                }
            }
            return uniqueEmailList.Count;
        }
    }
}