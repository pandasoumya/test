# React Code Challenge: Create a Component

## Instructions

1. Install Node (LTS or latest).
2. Build `npm install`.
3. Run `npm start`.
4. The application will appear in your browser.
5. Instructions to complete the challenge are written into [the webpage](http://localhost:3000).

## Learn More

To learn React, check out the [React documentation](https://reactjs.org/).
