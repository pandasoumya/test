import { Component, Input } from '@angular/core';

@Component({
  selector: 'apple',
  template: `<emoji-c e='🍎'></emoji-c>`,
})
export class AppleComponent {}
