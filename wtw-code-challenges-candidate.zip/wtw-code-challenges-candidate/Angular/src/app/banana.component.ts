import { Component, Input } from '@angular/core';

@Component({
  selector: 'banana',
  template: `<emoji-c e='🍌'></emoji-c>`,
})
export class BananaComponent {}
