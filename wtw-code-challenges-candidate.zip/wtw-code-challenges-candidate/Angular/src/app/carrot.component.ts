import { Component, Input } from '@angular/core';

@Component({
  selector: 'carrot',
  template: `<emoji-c e='🥕'></emoji-c>`,
})
export class CarrotComponent {}
