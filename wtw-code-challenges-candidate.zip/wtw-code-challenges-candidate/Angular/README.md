# Angular Code Challenge: Create a Component

## Instructions

1. Install Node (LTS or latest).
2. Build `npm install`.
3. Run `npm start`.
4. The application will be available at <http://localhost:4200>.
5. Instructions to complete the challenge are written into the webpage.

## Learn More

To learn Angular, check out the [Angular documentation](https://angular.io/).
